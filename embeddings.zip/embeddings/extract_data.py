import pandas as pd

# Read the CSV file
df = pd.read_csv('matched_raw_metadata_1963_unique.csv')

# Keep only the specified columns
df_filtered = df[['meta_evidence_serial_number', 'video_file_address']].copy()

# Rename columns
df_filtered.columns = ['evidence_id', 'path']

# Replace path prefix
df_filtered.loc[:, 'path'] = df_filtered['path'].str.replace('/media/padte/toshiba20TB', '/mnt/synology/BWVs')

# Save to a new file
df_filtered.to_csv('filtered_metadata.csv', index=False)

print("File created successfully!")