# CUDA_VISIBLE_DEVICES
import os
import csv
import math
import torch
import subprocess
from pathlib import Path
from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor
from qwen_vl_utils import process_vision_info

# ---------------- CONFIG ----------------
input_csv = "fake_data.csv"
H = 360
W = 420
output_dir = f"samples"
path_column = "path"
device = "auto"
chunk_duration = 30  # seconds
tmp_dir = Path("./tmp")
# ----------------------------------------

os.makedirs(output_dir, exist_ok=True)
tmp_dir.mkdir(exist_ok=True)

# ---------------- LOAD MODEL ----------------
model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    "Qwen/Qwen2.5-VL-3B-Instruct",
    torch_dtype=torch.bfloat16,
    attn_implementation="flash_attention_2",
    device_map=device,
)
processor = AutoProcessor.from_pretrained(
    "Qwen/Qwen2.5-VL-3B-Instruct"
)
model.config.vision_config.spatial_merge_size = 1
model.config.vision_config.merge_size = 1
# ---------------- UTIL: GET VIDEO DURATION ----------------
def get_video_duration(video_path):
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(video_path)
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return float(result.stdout)

# ---------------- UTIL: SPLIT VIDEO ----------------
def split_video_into_chunks(video_path, chunk_duration, tmp_dir):
    duration = get_video_duration(video_path)
    num_chunks = math.ceil(duration / chunk_duration)

    chunk_paths = []

    for i in range(num_chunks):
        start_time = i * chunk_duration
        out_path = tmp_dir / f"{video_path.stem}_chunk_{i}.mp4"

        cmd = [
            "ffmpeg",
            "-y",
            "-ss", str(start_time),
            "-i", str(video_path),
            "-t", str(chunk_duration),
            "-c", "copy",
            str(out_path),
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        if out_path.exists():
            chunk_paths.append(out_path)

    return chunk_paths

# ---------------- EMBEDDING FUNCTION ----------------
def extract_embedding(video_path: str):
    messages = [
        {
            "role": "user",
            "content": [
                {"type": "video", "video": video_path, "max_pixels": H * W, "fps": 2.0},
                {"type": "text", "text": "Describe this video."},
            ],
        }
    ]

    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    image_inputs, video_inputs, video_kwargs = process_vision_info(
        messages, return_video_kwargs=True
    )

    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt",
        **video_kwargs,
    ).to(model.device)
    # assert False, inputs.keys()
    with torch.no_grad():
        embeds = model.visual(
            inputs["pixel_values_videos"],
            grid_thw=inputs["video_grid_thw"]
        )
    print(f"Extracted embedding shape: {embeds.shape}")
    return embeds.cpu()

# ---------------- MAIN LOOP ----------------
with open(input_csv, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for row in reader:
        video_path = row.get(path_column, "")
        evidence_ID = row.get("evidence_id", "")

        if not video_path or video_path.strip().lower() == "none":
            continue

        video_path = Path(video_path)

        if not video_path.exists():
            print(f"⚠️ Skipping, file not found: {video_path}")
            continue

        try:
            print(f"\n🎬 Processing long video: {video_path}")

            # 1️⃣ Split into chunks
            chunk_paths = split_video_into_chunks(
                video_path, chunk_duration, tmp_dir
            )

            if len(chunk_paths) == 0:
                print("⚠️ No chunks created.")
                continue

            chunk_embeddings = []

            # 2️⃣ Extract embeddings per chunk
            for chunk in chunk_paths:
                print(f"   ➜ Chunk: {chunk.name}")
                emb = extract_embedding(str(chunk))
                chunk_embeddings.append(emb)

            # 3️⃣ Aggregate embeddings
            # Option A: mean pooling
            final_embedding = torch.cat(chunk_embeddings, dim=0)

            # Alternative aggregation:
            # final_embedding = torch.cat(chunk_embeddings, dim=1)

            # 4️⃣ Save final embedding
            out_file = Path(output_dir) / f"{evidence_ID}.pt"
            torch.save(final_embedding, out_file)
            print(f"✅ Saved aggregated embedding: {out_file}")

            # 5️⃣ Cleanup temp files
            for chunk in chunk_paths:
                chunk.unlink()

        except Exception as e:
            print(f"❌ Failed {video_path}: {e}")