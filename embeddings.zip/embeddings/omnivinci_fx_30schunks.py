#!/usr/bin/env python3
# extract_long_video_omnivinci.py
import os
import csv
import math
import subprocess
from pathlib import Path
import torch

# --- CONFIG ------------------------------------------------
input_csv = "fake_data.csv"        # CSV must have columns: path, evidence_id
path_column = "path"
evidence_column = "evidence_id"
chunk_duration = 30                # seconds per chunk
tmp_dir = Path("./tmp")
output_dir = Path("samples")
H, W = 448, 448                    # set to your desired max_pixels shape (example)
device = "cuda" if torch.cuda.is_available() else "cpu"

# Omnivinci model path (change to your local path)
omnivinci_path = "./omnivinci_model"

# Sampling controls
fps = 1.0                          # frames per second you want (1 fps -> 30 frames for 30s)
num_video_frames = int(chunk_duration * fps)  # frames per chunk to request
# ----------------------------------------------------------

os.makedirs(output_dir, exist_ok=True)
tmp_dir.mkdir(exist_ok=True)

# ----------------- ffprobe duration ------------------------
def get_video_duration(video_path: Path) -> float:
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        str(video_path)
    ]
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise RuntimeError(f"ffprobe failed for {video_path}: {p.stderr.decode()}")
    return float(p.stdout)

# ----------------- split video into chunks ----------------
def split_video_into_chunks(video_path: Path, chunk_duration: int, tmp_dir: Path):
    duration = get_video_duration(video_path)
    num_chunks = math.ceil(duration / chunk_duration)
    chunk_paths = []
    for i in range(num_chunks):
        start_time = i * chunk_duration
        out_path = tmp_dir / f"{video_path.stem}_chunk_{i}.mp4"
        # use -ss before -i for speed, -t for duration, copy codec
        cmd = [
            "ffmpeg", "-y",
            "-ss", str(start_time),
            "-i", str(video_path),
            "-t", str(chunk_duration),
            "-c", "copy",
            str(out_path)
        ]
        subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if out_path.exists():
            chunk_paths.append(out_path)
    return chunk_paths

# ----------------- Load Omnivinci (VILA) -------------------
from transformers import AutoConfig, AutoProcessor, AutoModel

print("Loading Omnivinci model... this may take a while.")
config = AutoConfig.from_pretrained(omnivinci_path, trust_remote_code=True)

# load model
model = AutoModel.from_pretrained(
    omnivinci_path,
    trust_remote_code=True,
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    device_map="auto" if torch.cuda.is_available() else None,
)
model.eval()

# adjust encoder config to preserve temporal axis (no pooling) and set number of frames
# NOTE: pool_sizes controls pooling (temporal, h, w). Set temporal pooling to 1 to keep time.
if "video_encoder" in model.config:
    model.config.video_encoder["pool_sizes"] = [[1, 1, 1]]
else:
    # Some checkpoints may have slightly different key
    model.config.video_encoder = {"pool_sizes": [[1, 1, 1]]}

# set model-wide guidance for number of frames and audio/video settings
model.config.num_video_frames = num_video_frames
model.config.load_audio_in_video = False   # keep False unless you want audio
# If your config uses other keys (e.g., 'video_max_frames') set them similarly:
# model.config.video_max_frames = num_video_frames

# Load processor and set its params to match
processor = AutoProcessor.from_pretrained(omnivinci_path, trust_remote_code=True)
processor.config.num_video_frames = num_video_frames
processor.config.load_audio_in_video = False

print("Model & processor loaded. num_video_frames =", num_video_frames)

# ----------------- Utility: extract chunk embedding via encoder ----------------
def extract_chunk_embedding_omnivinci(chunk_path: Path, chunk_idx: int):
    """
    Prepare conversation with a <video> token and run the video encoder directly.
    Returns: a torch.Tensor of shape [T' * N, C] or [N, C] depending on encoder behavior,
             where T' is temporal windows (if pool_sizes preserved, T'=num_video_frames).
    """
    conversation = [{
        "role": "user",
        "content": [
            {"type": "video", "video": str(chunk_path), "max_pixels": H * W, "fps": fps},
            {"type": "text", "text": "Describe this video."}
        ],
    }]
    # prepare text template
    text = processor.apply_chat_template(conversation, tokenize=False, add_generation_prompt=True)

    # Use processor to produce media tensors (the same style as your example)
    # NOTE: we pass max_pixels to processor to ensure consistent sizing
    inputs = processor([text], max_pixels=H * W)
    # Move tensors to model device & dtype
    inputs = inputs.to(model.device).to(model.dtype)

    # The processor creates:
    # - inputs.media["video"] : list of tensor(s) per sample (each tensor shape e.g. [T, 3, H', W'])
    # - inputs.media_config["video"] : config per video (block_sizes etc)
    media = getattr(inputs, "media", None)
    media_config = getattr(inputs, "media_config", None)
    if media is None or "video" not in media:
        raise RuntimeError("Processor did not produce video media for chunk: " + str(chunk_path))

    # mm_info needed by some encoders
    mm_info = media  # Omnivinci TSPVideoEncoder expects the dict with video_info etc.

    # Call the video encoder directly:
    # Note: model.encoders['video'] is a TSPVideoEncoder instance that accepts:
    #    videos: List[torch.Tensor]  (each element: [T, C, H, W] or CacheFeatures)
    #    config: media_config['video'] (dict/list)
    #    mm_info: dict (contains video_info)
    video_list = media["video"]        # list of video tensors for batch (we have 1)
    video_media_config = None
    if media_config is not None and "video" in media_config:
        video_media_config = media_config["video"]

    with torch.no_grad():
        # encoder returns a list of processed features (one entry per video sub-item)
        # Each element is a torch.Tensor shaped [N_tokens, C] (N_tokens = T'*spatial or spatial if pooled)
        video_features = model.encoders["video"](video_list, video_media_config, mm_info=mm_info)
        # video_features is a Python list with one entry per video "region" (usually one entry per chunk)
        # Commonly: video_features[0].shape == [num_tokens, hidden_size]
    if not isinstance(video_features, list):
        raise RuntimeError("Unexpected encoder output type, expected list.")

    # For a single chunk, we usually get one tensor per original video segment; get first
    # If the encoder returns multiple entries (multiple processed blocks), concat them in order
    emb = torch.cat(video_features, dim=0) if len(video_features) > 1 else video_features[0]

    # Move to CPU and return
    return emb.cpu()

# ----------------- Main loop: iterate CSV and produce aggregated embeddings ----------------
with open(input_csv, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        vid_path = row.get(path_column, "")
        evidence_ID = row.get(evidence_column, "") or Path(vid_path).stem
        if not vid_path or vid_path.strip().lower() == "none":
            continue
        video_path = Path(vid_path)
        if not video_path.exists():
            print(f"Skipping not found: {video_path}")
            continue

        try:
            print(f"\nProcessing {video_path} ...")
            chunk_paths = split_video_into_chunks(video_path, chunk_duration, tmp_dir)
            if len(chunk_paths) == 0:
                print("No chunks created, skipping.")
                continue

            chunk_embeddings = []
            for i, chunk in enumerate(chunk_paths):
                print(f"  Chunk {i+1}/{len(chunk_paths)}: {chunk.name}")
                emb = extract_chunk_embedding_omnivinci(chunk, i)
                # emb shape: [num_tokens_for_chunk, hidden_size]
                print(f"    → chunk embedding: {tuple(emb.shape)}")
                chunk_embeddings.append(emb)

            # Aggregate: stack chunks in time-order by concatenating along token/time axis (dim=0)
            # This preserves the per-chunk token sequence; you can also save as list if you prefer
            final_embedding = torch.cat(chunk_embeddings, dim=0) if len(chunk_embeddings) > 1 else chunk_embeddings[0]

            out_file = output_dir / f"{evidence_ID}.pt"
            torch.save(final_embedding, out_file)
            print(f"Saved: {out_file}  (shape: {tuple(final_embedding.shape)})")

            # cleanup tmp chunks
            for c in chunk_paths:
                try:
                    c.unlink()
                except Exception:
                    pass

        except Exception as e:
            print(f"Failed {video_path}: {repr(e)}")